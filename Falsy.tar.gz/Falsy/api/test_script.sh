#!/bin/bash

echo $MONGODB_HOST
export mongoIP=$MONGODB_HOST
#echo mongoIP
echo $apiIP
export $apiIP

echo $apiid
export $apiid

# echo test_script_results
# echo $api6
# echo $mongodb6
# export apiIP=$api6
# export mongoIP=$mongodb6
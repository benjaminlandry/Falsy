import os
abc=os.environ.get('MONGODB_HOST')
print(abc)
